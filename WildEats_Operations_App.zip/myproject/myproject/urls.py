from django.contrib import admin
from django.urls import path, include

urlpatterns = [

    path('admin/', admin.site.urls),


    path('operations/', include('operations.urls')),


    path('', include('operations.urls')),
]